﻿/////////////////////////////////////////////////////////////////////
// Client.cs - Demonstrate application use of channel              //
// Ver 1.0                                                         //
// Sneha Patil, CSE681 - Software Modeling and Analysis, Fall 2016 //
/////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * The Client package defines one class, Client, that uses the Comm<Client>
 * class to pass messages to a remote endpoint.
 * 
 * Required Files:
 * ---------------
 * - Client.cs
 * - ICommunicator.cs, CommServices.cs
 * - Messages.cs, MessageTest, Serialization
 *
 * Maintenance History:
 * --------------------
 * Ver 1.0 : 10 Nov 2016
 * - first release 
 *  
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Messages;

namespace WCF_Peer_Comm
{
  ///////////////////////////////////////////////////////////////////
  // Client class demonstrates how an application uses Comm
  //
 public class Client
  {
    public Comm<Client> comm { get; set; } = new Comm<Client>();

    public string endPoint { get; } = Comm<Client>.makeEndPoint("http://localhost", 8088);

    private Thread rcvThread = null;

    //----< initialize receiver >------------------------------------

    public Client()
    {
      comm.rcvr.CreateRecvChannel(endPoint);
      rcvThread = comm.rcvr.start(rcvThreadProc);
    }
    //----< join receive thread >------------------------------------

    public void wait()
    {
      rcvThread.Join();
    }
    //----< construct a basic message >------------------------------

    public Messages.Message makeMessage(string author, string fromEndPoint, string toEndPoint)
    {
      Messages.Message msg = new Messages.Message();
      msg.author = author;
      msg.from = fromEndPoint;
      msg.to = toEndPoint;
      return msg;
    }
    //----< use private service method to receive a message >--------
     
    void rcvThreadProc()
    {
      while (true)
      {
        Messages.Message msg = comm.rcvr.GetMessage();
        msg.time = DateTime.Now;
        Console.Write("\n ------- {0} received message from {1}: ----", comm.name, msg.from);
        msg.show();
        ParseMessage(msg);
        if (msg.body == "quit")
          break;
      }
    }

        //Parsing the received message

        public void ParseMessage(Messages.Message msg)
        {
            switch (msg.type)
            {
                case "QueryResults":
                    Message nmsg = GetLogs(msg, 1);
                    comm.sndr.PostMessage(nmsg);
                    nmsg.show();
                    break;
              
                default:
                   // Console.WriteLine("unknown command");
                    break;
            }
        }

        //Querying the repository

        public Messages.Message makeQuery(string queryText, string to, string from)
        {
            Console.Write("\n  Results of client query for \"" + queryText + "\"");
            Message msg = new Message();
            msg.to = to;
            msg.from = from;
            msg.type = "QueryLogs";
            msg.body = queryText;
            return msg;
        }

        //Getting logs from repository folder

        public Messages.Message GetLogs(Messages.Message msg, int fileNo)
        {
            char[] delimeter = { ',' };
            string[] lines = msg.body.Split(delimeter);
            foreach(string line in lines)
            {
                Console.WriteLine(" Requirement Query 9:Results Received by Clent from Repository : " + line);
            }
            Messages.Message newMsg = makeMessage(msg.author, endPoint, msg.from);
            newMsg.type = "TestResults";
            newMsg.body = lines[fileNo];
            return newMsg;
        }

        //Building the first test request

        Message buildTestMessage1(string author , string to , string from)
        {
            Message msg = new Message();
            msg.to = to;
            msg.from = from;
            msg.author = author;
            msg.type = "Test Request";
            testElement te1 = new testElement("test1");
            te1.addDriver("testdriver.dll");
            te1.addCode("testedcode.dll");
            testElement te3 = new testElement("test3");
            te3.addDriver("anothertestdriver.dll");
            te3.addCode("anothertestedcode.dll");
            testElement tlg = new testElement("loggerTest");
            testRequest tr = new testRequest();
            tr.author = author;
            tr.tests.Add(te1);
            tr.tests.Add(te3);
            tr.tests.Add(tlg);
            msg.body = tr.ToString();
            return msg;
        }

        //Building the second test request

        Message buildTestMessage2(string author, string to, string from)
        {
            Message msg = new Message();
            msg.to = to;
            msg.from = from;
            msg.author = author;
            msg.type = "Test Request";
            testElement te1 = new testElement("test3");
            te1.addDriver("TestDriver1.dll");
            te1.addCode("CodeToTest1.dll");
            testElement te2 = new testElement("test4");
            te2.addDriver("td1.dll");
            te2.addCode("tc1.dll");
            testRequest tr = new testRequest();
            tr.author = author;
            tr.tests.Add(te1);
            tr.tests.Add(te2);
            msg.body = tr.ToString();
            return msg;
        }
        //----< run client demo >----------------------------------------

    static void Main(string[] args)
    {
      Console.Title = "//////////////////*****Clent1 Starting********/////////////////////////////";
      Console.Write("\n  Testing Client Demo");
      Console.Write("\n =====================\n");
      object sync_ = new object();
      Client client = new Client();
      client.comm.sndr.channel = Sender.CreateServiceChannel("http://localhost:8000/StreamService");
      client.comm.sndr.ToSendPath = "..\\..\\..\\ToSend";
      Console.Write("\nRequirement 6: Sending files to repository");
      lock (sync_)
      {
         client.comm.sndr.uploadFile("TestDriver1.dll");
         client.comm.sndr.uploadFile("CodeToTest1.dll");
      }
      Console.Write("\nRequirement 6: Sending requests to test harness");
      string remoteEndPoint = Comm<Client>.makeEndPoint("http://localhost", 8082);
      string repoEndPoint = Comm<Client>.makeEndPoint("http://localhost", 8080);

      Message msg = client.buildTestMessage1("Sneha", remoteEndPoint, client.endPoint);
      client.comm.sndr.PostMessage(msg);
      msg.show();
      msg = client.buildTestMessage2("SnehaPatil", remoteEndPoint, client.endPoint);
      client.comm.sndr.PostMessage(msg);
      msg.show();
            lock (sync_)
            {
                Console.WriteLine(" Requirement Query 9:Query requestby Clent to test harness/n Query text: \"test1\"");
                msg = client.makeQuery("test1", repoEndPoint, client.endPoint);
                client.comm.sndr.PostMessage(msg);
                msg.show();
            }
      Console.Write("\n ");
      Console.ReadKey();
      msg.to = client.endPoint;
      msg.body = "quit";
      client.comm.sndr.PostMessage(msg);
      client.wait();
      Console.Write("\n\n");
    }
  }
}
