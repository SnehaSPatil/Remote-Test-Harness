﻿// Receiver.cs - Peer-To-Peer Communicator Service Receiver implemetation  //
// ver 2.0                                                             //
// Author: Sneha Patil                                                 //
// Jim Fawcett, CSE681 - Software Modeling & Analysis, Summer 2011     //
/////////////////////////////////////////////////////////////////////////
/*
* Package Operations:
 * -------------------
 * Communicator Service Receiver implemetation
 * 
 * Required Files:
 * ---------------
 * - ICommunicator.cs,
 * - Messages.cs, 
 *
 * Maintenance History:
 * ====================
 * 
 * ver 1.0 : 14 Jul 07
 * - first release
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;
using SWTools;
using System.ServiceModel.Channels;
using System.IO;

namespace WCF_Peer_Comm
{
    /////////////////////////////////////////////////////////////
    // Receiver hosts Communication service used by other Peers
    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class Receiver<T> : ICommunicator
    {
        static BlockingQueue<Messages.Message> rcvBlockingQ = null;
        ServiceHost service = null;
        string filename;
        public string savePath { get; set; } = "..\\..\\RepositoryStorage";
        public string ToSendPath { get; set; } = "..\\..\\RepositoryStorage";
        int BlockSize = 1024;
        byte[] block;
        HRTimer.HiResTimer hrt = null;
        public string name { get; set; }

        public Receiver()
        {
            if (rcvBlockingQ == null)
                rcvBlockingQ = new BlockingQueue<Messages.Message>();
            block = new byte[BlockSize];
            hrt = new HRTimer.HiResTimer();
        }
        public Thread start(ThreadStart rcvThreadProc)
        {
            Thread rcvThread = new Thread(rcvThreadProc);
            rcvThread.Start();
            return rcvThread;
        }

        public void Close()
        {
            service.Close();
        }

        //  Create ServiceHost for Communication service

        public void CreateRecvChannel(string address)
        {
            BasicHttpBinding binding = new BasicHttpBinding();
            Uri baseAddress = new Uri(address);
            service = new ServiceHost(typeof(Receiver<T>), baseAddress);
            service.AddServiceEndpoint(typeof(ICommunicator), binding, baseAddress);
            service.Open();
        }


        public void upLoadFile(FileTransferMessage msg)
        {
            int totalBytes = 0;
            hrt.Start();
            filename = msg.filename;
            string rfilename = Path.Combine(savePath, filename);
            if (!Directory.Exists(savePath))
                Directory.CreateDirectory(savePath);
            using (var outputStream = new FileStream(rfilename, FileMode.Create))
            {
                while (true)
                {
                    int bytesRead = msg.transferStream.Read(block, 0, BlockSize);
                    totalBytes += bytesRead;
                    if (bytesRead > 0)
                        outputStream.Write(block, 0, bytesRead);
                    else
                        break;
                }
            }
            hrt.Stop();
            Console.Write(
              "\n  Received file \"{0}\" of {1} bytes in {2} microsec.",
              filename, totalBytes, hrt.ElapsedMicroseconds
            );
        }

        public Stream downLoadFile(string filename)
        {
            hrt.Start();
            string sfilename = Path.Combine(ToSendPath, filename);
            FileStream outStream = null;
            if (File.Exists(sfilename))
            {
                outStream = new FileStream(sfilename, FileMode.Open);
            }
            else
            {
                throw new Exception("open failed for \"" + filename + "\"");

            }
            hrt.Stop();
            Console.Write("\n  Sent \"{0}\" in {1} microsec.", filename, hrt.ElapsedMicroseconds);
            return outStream;
        }

        public static ServiceHost CreateServiceChannel(string url)
        {
            // Can't configure SecurityMode other than none with streaming.
            BasicHttpBinding binding = new BasicHttpBinding();
            binding.TransferMode = TransferMode.Streamed;
            binding.MaxReceivedMessageSize = 50000000;
            Uri baseAddress = new Uri(url);
            Type service = typeof(WCF_Peer_Comm.Receiver<T>);
            ServiceHost host = new ServiceHost(service, baseAddress);
            host.AddServiceEndpoint(typeof(ICommunicator), binding, baseAddress);
            return host;
        }

        // Implement service method to receive messages from other Peers

        public void PostMessage(Messages.Message msg)
        {
            rcvBlockingQ.enQ(msg);
        }

        // Implement service method to extract messages from other Peers.
        // This will often block on empty queue, so user should provide
        // read thread.

        public Messages.Message GetMessage()
        {
            return rcvBlockingQ.deQ();
        }

#if (TEST_COMMSERVICE)

  class Cat { }
  class TestComm
  {
    [STAThread]
    static void Main(string[] args)
    {
      Comm<Cat> comm = new Comm<Cat>();
      string endPoint = Comm<Cat>.makeEndPoint("http://localhost", 8080);
      comm.rcvr.CreateRecvChannel(endPoint);
      comm.rcvr.start(comm.thrdProc);
      Console.Write("\n  Comm Service Running:");
      Console.Write("\n  Press key to quit");
      Console.ReadKey();
      Console.Write("\n\n");
    }
#endif
    }
}
