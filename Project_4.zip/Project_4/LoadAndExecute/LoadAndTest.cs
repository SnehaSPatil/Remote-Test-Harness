﻿/////////////////////////////////////////////////////////////////////
// LoadAndTest.cs - loads and executes tests using reflection      //
// ver 2.0                                                         //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2016 //
/////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * LoadAndTest package operates in child AppDomain.  It loads and
 * executes test code defined by a TestRequest message.
 *
 * Required files:
 * ---------------
 * - LoadAndTest.cs
 * - ITest.cs
 * - Logger, Messages
 * 
 * Maintanence History:
 * --------------------
 * ver 2.0 : 13 Nov 2016
 * - remove logger statements
 * - added thread id markers on displays
 * - modified some of the error handling
 * ver 1.1 : 11 Oct 2016
 * - now loading files using absolute path evaluated
 *   for the machine on which this application runs
 * ver 1.0 : 16 Oct 2016
 * - first release
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Reflection;
using System.Threading;
using Messages;

namespace TestHarness
{
    public class LoadAndTest : MarshalByRefObject, ILoadAndTest
    {
        private ICallback cb_ = null;
        private string loadPath_ = "";
        object sync_ = new object();

        ///////////////////////////////////////////////////////
        // Data Structures used to store test information
        //
        [Serializable]
        private class TestResult : ITestResult
        {
            public string testName { get; set; }
            public string testResult { get; set; }
            public string testLog { get; set; }
        }
        [Serializable]
        private class TestResults : ITestResults
        {
            public string testKey { get; set; }
            public DateTime dateTime { get; set; }
            public List<ITestResult> testResults { get; set; } = new List<ITestResult>();
        }
        TestResults testResults_ = new TestResults();

        //----< initialize loggers >-------------------------------------

        public LoadAndTest()
        {
        }
        public void loadPath(string path)
        {
            loadPath_ = path;
            Console.Write("\n  loadpath = {0}", loadPath_);
        }
        //----< load libraries into child AppDomain and test >-----------
        /*
         * ToDo:
         * - refactor this function to make it more testable.
         */
        public Assembly createAssembly(Assembly assem, string file)
        {

            if (loadPath_.Count() > 0)
            {
                for (int i = 0; i < 5; ++i)
                {
                    try
                    {
                        assem = Assembly.LoadFrom(loadPath_ + "/" + file);
                        break;
                    }
                    catch
                    {
                        Thread.Sleep(100);
                    }
                }
            }
            else
                assem = Assembly.Load(file);

            return assem;
        }


        private TestResult giveresults(ITest tdr, TestResult testResult, string testDriverName)
        {
            bool testReturn;
            try
            {
                testReturn = tdr.test();
            }
            catch
            {
                //Console.Write("\n----exception thrown in " + fileName);
                testReturn = false;
            }
            if (tdr != null && testReturn == true)
            {
                testResult.testResult = "passed";
                testResult.testLog = tdr.getLog();
                Console.Write("\n    TID" + Thread.CurrentThread.ManagedThreadId + ": test passed");
                if (cb_ != null)
                {
                    cb_.sendMessage(new Message(testDriverName + " passed"));
                }
            }
            else
            {
                testResult.testResult = "failed";
                if (tdr != null)
                    testResult.testLog = tdr.getLog();
                else
                    testResult.testLog = "file not loaded";
                Console.Write("\n    TID" + Thread.CurrentThread.ManagedThreadId + ": test failed");
                if (cb_ != null)
                {
                    cb_.sendMessage(new Message(testDriverName + ": failed"));
                }
            }
            return testResult;
        }


        public ITestResults test(IRequestInfo testRequest,Messages.Message RQmsg)
        {
            TestResults testResults = new TestResults();
            foreach (ITestInfo test in testRequest.requestInfo)
            {
                TestResult testResult = new TestResult();
                testResult.testName = test.testName;
                try
                {
                    Console.Write("\n  TID" + Thread.CurrentThread.ManagedThreadId + ": -- \"" + test.testName + "\" --");
                    ITest tdr = null;
                    string testDriverName = "";
                    string fileName = "";
                    foreach (string file in test.files)
                    {
                        fileName = file;
                        Assembly assem = null;
                        try
                        {   assem = createAssembly(assem, file); }
                        catch
                        {
                            testResult.testResult = "failed";
                            testResult.testLog = "file not loaded";
                            Console.Write("\n    TID" + Thread.CurrentThread.ManagedThreadId + ": can't load\"" + file + "\"");
                            continue;
                        }
                        Console.Write("\n    TID" + Thread.CurrentThread.ManagedThreadId + ": loaded \"" + file + "\"");
                        Type[] types = assem.GetExportedTypes();
                        foreach (Type t in types)
                        {
                            if (t.IsClass && typeof(ITest).IsAssignableFrom(t))  // does this type derive from ITest ?
                            {
                                try
                                {
                                    testDriverName = file;
                                    tdr = (ITest)Activator.CreateInstance(t);    // create instance of test driver
                                    Console.Write("\n    TID" + Thread.CurrentThread.ManagedThreadId + ": " + testDriverName + " Reuirement 5: implements ITest interface ");
                                }
                                catch
                                {  continue;  }  } } }
                    Console.Write("\n    TID" + Thread.CurrentThread.ManagedThreadId + ": testing " + testDriverName);
                    testResult = giveresults(tdr, testResult, testDriverName);
                }
                catch (Exception ex)
                {
                    testResult.testResult = "failed";
                    testResult.testLog = "exception thrown";
                    Console.Write("\n  TID" + Thread.CurrentThread.ManagedThreadId + ": " + ex.Message);
                }
                testResults_.testResults.Add(testResult);
            }
            testResults_.dateTime = DateTime.Now;
            testResults_.testKey = System.IO.Path.GetFileName(loadPath_);
            return testResults_;
        }

        //Sending message to test harness that downloading failed
        void SendFileTransferFailedMessage(Messages.Message msg, string file)
        {
            Console.Write("\n    TID" + Thread.CurrentThread.ManagedThreadId + ": can't load\"" + file + "\"");
            Messages.Message nmsg = new Messages.Message();
            nmsg.author = "Test Harness";
            nmsg.to = msg.from;
            nmsg.from = msg.to;
            nmsg.type = "Error Message: File not Found";
            nmsg.body = file;
            if (cb_ != null)
            {
                cb_.sendMessage(nmsg);
            }
        }
        //----< TestHarness calls to pass ref to Callback function >-----

        public void setCallback(ICallback cb)
        {
            cb_ = cb;
        }

#if (Test_LoadTest)

        //----< retrieve test information from testRequest >-------------
        class program
        {
            List<ITestInfo> extractTests(Messages.Message testRequest)
            {
                Console.Write("\n  parsing test request");
                List<ITestInfo> tests = new List<ITestInfo>();
                XDocument doc = XDocument.Parse(testRequest.body);
                foreach (XElement testElem in doc.Descendants("test"))
                {
                    Test test = new Test();
                    string testDriverName = testElem.Element("testDriver").Value;
                    test.testName = testElem.Attribute("name").Value;
                    test.files.Add(testDriverName);
                    foreach (XElement lib in testElem.Elements("library"))
                    {
                        test.files.Add(lib.Value);
                    }
                    tests.Add(test);
                }
                return tests;
            }
            //----< retrieve test code from testRequest >--------------------

            List<string> extractCode(List<ITestInfo> testInfos)
            {
                Console.Write("\n  retrieving code files from testInfo data structure");
                List<string> codes = new List<string>();
                foreach (ITestInfo testInfo in testInfos)
                    codes.AddRange(testInfo.files);
                return codes;
            }
            static void Main(string[] args)
            {
                Messages.Message msg = new Messages.Message();
                IRequestInfo rqi = new IRequestInfo();
                rqi.requestInfo = extractTests(msg);
                List<string> files = extractCode(rqi.requestInfo);

            }
        }
#endif
        
    }
}
