﻿/////////////////////////////////////////////////////////////////////
// MainWindow1.xaml.cs - WPF User Interface for WCF Communicator   //
// ver 2.2                                                         //
// Sneha Patil, CSE681 - Software Modeling & Analysis, Summer 2016 //
/////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * GUI support for the test harness client
 *
 * Required Files:
 * MainWindow1.xaml.cs, Form1.cs
 *
 * Maintenance History:
 * ====================
 * 
 * ver 1.0 : 17 Jul 16
 * - first release
 */




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using WCF_Peer_Comm;
using Messages;

namespace WpfClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<string> foundfiles = new List<string>();
        public List<Messages.testElement> tests { get; set; } = new List<Messages.testElement>();
        public Comm<MainWindow> comm { get; set; } = new Comm<MainWindow>();
        public string TestHendPoint { get; } = Comm<MainWindow>.makeEndPoint("http://localhost", 8082);
        public string endPoint { get; } = Comm<MainWindow>.makeEndPoint("http://localhost", 8001);
        private Thread rcvThread = null;
        Messages.Message rcvdMsg = null;
        string repoEndPoint = Comm<MainWindow>.makeEndPoint("http://localhost", 8080);
        string repoFileEndPoint = Comm<MainWindow>.makeEndPoint("http://localhost", 8000);
        delegate void NewMessage(Messages.Message msg);
        event NewMessage OnNewMessage;
        string LogFilePath = "..\\..\\..\\WpfClient1\\Rlogs";
        IAsyncResult cbResult;
        public MainWindow()
        {
            InitializeComponent();
            comm.rcvr.CreateRecvChannel(endPoint);
            rcvThread = new Thread(new ThreadStart(this.rcvThreadProc));
            rcvThread.IsBackground = true;
            rcvThread.Start();
            OnNewMessage += new NewMessage(OnNewMessageHandler);

        }

        void rcvThreadProc()
        {
            while (true)
            {
                // get message out of receive queue - will block if queue is empty
                rcvdMsg = comm.rcvr.GetMessage();
                // call window functions on UI thread
                this.Dispatcher.BeginInvoke(
                  System.Windows.Threading.DispatcherPriority.Normal,
                  OnNewMessage,
                  rcvdMsg);
            }
        }

        void OnNewMessageHandler(Messages.Message msg)
        {
            if (msg.type == "QueryResults")
            {
                DisplayLogs(msg);
            }
            else if(msg.type == "LogResults")
            {
                Form1 frm = new Form1();
                frm.Show();
                frm.writeToTextBox(msg.body);
                saveLogs(msg);
            }
            else
            {
                Form1 frm = new Form1();
                frm.Show();
                frm.writeToTextBox(msg.body);
            }
        }


        void saveLogs(Messages.Message msg)
        {
            char[] delimeter = { '\n' };
            string[] lines = msg.body.Split(delimeter);
            System.IO.File.WriteAllLines(System.IO.Path.Combine(LogFilePath, msg.userDefined), lines);
        }

        /*-- invoke on UI thread --------------------------------*/

        void showPath(string path)
        {
            textBlock1.Text = path;
        }
        /*-- invoke on UI thread --------------------------------*/

        void addFile(string file)
        {
            //listBox1.Items.Add(file);
            listBox2.Items.Insert(0, file);
            foundfiles.Add(file);

        }
        /*-- recursive search for files matching pattern --------*/

        void search(string path, string pattern)
        {
            /* called on asynch delegate's thread */
            if (Dispatcher.CheckAccess())
                showPath(path);
            else
                Dispatcher.Invoke(
                  new Action<string>(showPath),
                  System.Windows.Threading.DispatcherPriority.Background,
                  new string[] { path }
                );
            string[] files = System.IO.Directory.GetFiles(path, pattern);
            foreach (string file in files)
            {
                if (Dispatcher.CheckAccess())
                    addFile(file);
                else
                    Dispatcher.Invoke(
                      new Action<string>(addFile),
                      System.Windows.Threading.DispatcherPriority.Background,
                      new string[] { file }
                    );
            }
            string[] dirs = System.IO.Directory.GetDirectories(path);
            foreach (string dir in dirs)
                search(dir, pattern);
        }

        private void FindButton_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            string path = AppDomain.CurrentDomain.BaseDirectory;
            dlg.SelectedPath = path;
            DialogResult result = dlg.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                path = dlg.SelectedPath;
                string pattern = "*.dll";
                Action<string, string> proc = this.search;
                cbResult = proc.BeginInvoke(path, pattern, null, null);
            }
        }


        private void listBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }


        private void SendFiles_Click(object sender, RoutedEventArgs e)
        {
            object sync_ = new object();
            comm.sndr.channel = Sender.CreateServiceChannel("http://localhost:8000/StreamService");
            Console.Write("\n Sending files to repository");
                foreach (string path in foundfiles)
                {
                    comm.sndr.ToSendPath = System.IO.Path.GetDirectoryName(path);
                    string filename = System.IO.Path.GetFileName(path);
                    comm.sndr.uploadFile(filename);
                    label2.Tag = "Sending file "+ filename + " to Repository";
                }
        }


        private void btnSendRequests_Click(object sender, RoutedEventArgs e)
        {
            Window win = new Window();
            string remoteEndPoint = Comm<MainWindow>.makeEndPoint("http://localhost", 8082);
            Messages.Message msg = new Messages.Message();
            msg.to = remoteEndPoint;
            msg.from = endPoint;
            msg.author = textAuthorName.Text;
            msg.type = "Test Request";
            checktextblocks();
            Messages.testRequest tr = new Messages.testRequest();
            tr.author = textAuthorName.Text;
            foreach (Messages.testElement te1  in tests)
            {
                tr.tests.Add(te1);
            }
            msg.body = tr.ToString();
            comm.sndr.PostMessage(msg);
            tests.Clear();
        }

        private void checktextblocks()
        {
            if (string.IsNullOrEmpty(textTestName.Text) || string.IsNullOrEmpty(textTestCode.Text) ||
                 string.IsNullOrEmpty(textTestDriver.Text) || string.IsNullOrEmpty(textAuthorName.Text)
                 ) { return; }
            else {
                Messages.testElement te1 = new Messages.testElement(textTestName.Text);
                char[] delimeter = { ',',';' };
                string[] testCodes = textTestCode.Text.Split(delimeter);
                te1.addDriver(textTestDriver.Text);
                foreach (string testCode in testCodes)
                {
                    te1.addCode(testCode);
                }
                tests.Add(te1);
                textTestName.Clear();
                textTestCode.Clear();
                textTestDriver.Clear();
                btnSendRequests.IsEnabled = true;
            }
        }
        private void btnAddTests_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(textTestName.Text) || string.IsNullOrEmpty(textTestCode.Text) ||
                 string.IsNullOrEmpty(textTestDriver.Text) || string.IsNullOrEmpty(textAuthorName.Text)
                 ) { }
            else {
                Messages.testElement te1 = new Messages.testElement(textTestName.Text);
                string[] testCodes = textTestCode.Text.Split(',');
                te1.addDriver(textTestDriver.Text);
                foreach (string testCode in testCodes)
                {
                    te1.addCode(testCode);
                }
                tests.Add(te1);
                textTestName.Clear();
                textTestCode.Clear();
                textTestDriver.Clear();
                btnSendRequests.IsEnabled = true;
            }
        }

        Messages.Message buildTestMessage1(string author, string to, string from)
        {
            Messages.Message msg = new Messages.Message();
            msg.to = to;
            msg.from = from;
            msg.author = author;
            msg.type = "Test Request";
            Messages.testElement te1 = new Messages.testElement("test1");
            te1.addDriver("testdriver.dll");
            te1.addCode("testedcode.dll");
            Messages.testElement te3 = new Messages.testElement("test3");
            te3.addDriver("anothertestdriver.dll");
            te3.addCode("anothertestedcode.dll");
            Messages.testElement tlg = new Messages.testElement("loggerTest");
            Messages.testRequest tr = new Messages.testRequest();
            tr.author = author;
            tr.tests.Add(te1);
            tr.tests.Add(te3);
            tr.tests.Add(tlg);
            msg.body = tr.ToString();
            return msg;
        }

       

        private void logs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Messages.Message msg = new Messages.Message();
            msg.to = repoEndPoint;
            msg.from = endPoint;
            msg.type = "TestResults";
            msg.body = listBoxLogs.SelectedItem.ToString();
            comm.sndr.PostMessage(msg);
        }

        private Messages.Message makeQuery(string queryText, string to, string from)
        {
            Messages.Message msg = new Messages.Message();
            msg.to = to;
            msg.from = from;
            msg.type = "QueryLogs";
            msg.body = queryText;
            return msg;
        }

        private void SendQuery_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(textEnterQuery.Text))
            { }
            else
            {
                Messages.Message msg = makeQuery(textEnterQuery.Text, repoEndPoint, endPoint);
                comm.sndr.PostMessage(msg);
            }
        }
        public Messages.Message makeMessage(string author, string fromEndPoint, string toEndPoint)
        {
            Messages.Message msg = new Messages.Message();
            msg.author = author;
            msg.from = fromEndPoint;
            msg.to = toEndPoint;
            return msg;
        }

        public void DisplayLogs(Messages.Message msg)
        {
            char[] delimeter = { ',' };
            string[] lines = msg.body.Split(delimeter);
            foreach (string line in lines)
            {
                listBoxLogs.Items.Insert(0, line);
            }
        }
    }
}
