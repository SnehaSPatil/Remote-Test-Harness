﻿////////////////////////////////////////////////////////////////////////////
// TestHarness.cs - TestHarness Engine: creates child domains             //
// ver 2.2                                                                //
//Author: Sneha Patil, patil.snehas@gmail.com                             //            
//Source: Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2016 //
////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * TestHarness package provides integration testing services.  It:
 * - receives structured test requests
 * - retrieves cited files from a repository
 * - executes tests on all code that implements an ITest interface,
 *   e.g., test drivers.
 * - reports pass or fail status for each test in a test request
 * - stores test logs in the repository
 * It contains classes:
 * - TestHarness that runs all tests in child AppDomains
 * - Callback to support sending messages from a child AppDomain to
 *   the TestHarness primary AppDomain.
 * - Test and RequestInfo to support transferring test information
 *   from TestHarness to child AppDomain
 * 
 * Required Files:
 * ---------------
 * - TestHarness.cs, BlockingQueue.cs
 * - ITest.cs
 * - LoadAndTest, Logger, Messages
 *
 * Maintanence History:
 * --------------------
 * ver 2.2 : 17 Nov 2016
 * - added while loop in doTest lambda in ProcessMessages()
 * ver 2.1 : 15 Nov 2016
 * - removed logger test due to race condition in logger - will fix later
 * - Added custom thread local storage so that lock in runTests function
 *   could be removed.  
 * ver 2.0 : 13 Nov 2016
 * - added creation of threads to run tests in ProcessMessages
 * - removed logger statements as they were confusing with multiple threads
 * - added locking in a few places
 * - added more error handling
 * - No longer save temp directory name in member data of TestHarness class.
 *   It's now captured in TestResults data structure.
 * ver 1.1 : 11 Nov 2016
 * - added ability for test harness to pass a load path to
 *   LoadAndTest instance in child AppDomain
 * ver 1.0 : 16 Oct 2016
 * - first release
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Security.Policy;    // defines evidence needed for AppDomain construction
using System.Runtime.Remoting;   // provides remote communication between AppDomains
using System.Xml;
using System.ServiceModel.Channels;
using System.Xml.Linq;
using System.Threading;
using WCF_Peer_Comm;
namespace TestHarness
{
  ///////////////////////////////////////////////////////////////////
  // Callback class is used to receive messages from child AppDomain
  //
  public class Callback : MarshalByRefObject, ICallback
  {
    public void sendMessage(Messages.Message message)
    {
      Console.Write("\n :received msg from childDomain: \"" + message.body + "\"");
            if(message.type == "Error Message: File not Found")
            {
                Console.Write("\n************Requirement 3 :Sending Error message to Client :File not found *******************");
                Sender snd = new Sender();
                snd.PostMessage(message);
            }
        }
  }
  ///////////////////////////////////////////////////////////////////
  // Test and RequestInfo are used to pass test request information
  // to child AppDomain
  //
  [Serializable]
  class Test : ITestInfo
  {
    public string testName { get; set; }
    public List<string> files { get; set; } = new List<string>();
  }
  [Serializable]
  class RequestInfo : IRequestInfo
  {
    public string tempDirName { get; set; }
    public List<ITestInfo> requestInfo { get; set; } = new List<ITestInfo>();
  }
  ///////////////////////////////////////////////////////////////////
  // class TestHarness

  public class TestHarness : ITestHarness
  {
    private ICallback cb_;
    private string repoEndpt = Comm<TestHarness>.makeEndPoint("http://localhost", 8080);
    private string filePath_;
    object sync_ = new object();
    List<Thread> threads_ = new List<Thread>();
    Dictionary<int, string> TLS = new Dictionary<int, string>();
    public Comm<TestHarness> comm { get; set; } = new Comm<TestHarness>();

    public string endPoint { get; } = Comm<TestHarness>.makeEndPoint("http://localhost", 8082);
    private Thread rcvThread = null;

    public TestHarness(string endpt)
    {
      Console.Write("\n  creating instance of TestHarness");
      repoEndpt = endpt;
      cb_ = new Callback();
      comm.rcvr.CreateRecvChannel(endPoint);
      rcvThread = comm.rcvr.start(processMessages);
    }


    public void waitRcv()
   {
       rcvThread.Join();
   }

   public void SendMessage(string endpoint, Messages.Message msg)
   {
       comm.sndr = new WCF_Peer_Comm.Sender();
     //  comm.sndr.CreateSendChannel(endpoint);
       Console.WriteLine("\n\nsending message : " + msg);
       comm.sndr.PostMessage(msg);
   }

   public Messages.Message makeMessage(string author, string fromEndPoint, string toEndPoint)
    {
        Messages.Message msg = new Messages.Message();
        msg.author = author;
        msg.from = fromEndPoint;
        msg.to = toEndPoint;
       return msg;
    }

    //----< not used for Project #2 >--------------------------------

    public Messages.Message sendMessage(Messages.Message msg)
    {
      return msg;
    }
    //----< make path name from author and time >--------------------

    string makeKey(string author)
    {
      DateTime now = DateTime.Now;
      string nowDateStr = now.Date.ToString("d");
      string[] dateParts = nowDateStr.Split('/');
      string key = "";
      foreach (string part in dateParts)
        key += part.Trim() + '_';
      string nowTimeStr = now.TimeOfDay.ToString();
      string[] timeParts = nowTimeStr.Split(':');
      for (int i = 0; i < timeParts.Count() - 1; ++i)
        key += timeParts[i].Trim() + '_';
      key += timeParts[timeParts.Count() - 1];
      key = author + "_" + key + "_" + "ThreadID" + Thread.CurrentThread.ManagedThreadId;
      return key;
    }
    //----< retrieve test information from testRequest >-------------

    List<ITestInfo> extractTests(Messages.Message testRequest)
    {
      Console.Write("\n  parsing test request");
      List<ITestInfo> tests = new List<ITestInfo>();
      XDocument doc = XDocument.Parse(testRequest.body);
      foreach (XElement testElem in doc.Descendants("test"))
      {
        Test test = new Test();
        string testDriverName = testElem.Element("testDriver").Value;
        test.testName = testElem.Attribute("name").Value;
        test.files.Add(testDriverName);
        foreach (XElement lib in testElem.Elements("library"))
        {
          test.files.Add(lib.Value);
        }
        tests.Add(test);
      }
      return tests;
    }
    //----< retrieve test code from testRequest >--------------------

    List<string> extractCode(List<ITestInfo> testInfos)
    {
      Console.Write("\n  retrieving code files from testInfo data structure");
      List<string> codes = new List<string>();
      foreach (ITestInfo testInfo in testInfos)
        codes.AddRange(testInfo.files);
      return codes;
    }
    //----< create local directory and load from Repository >--------

    RequestInfo processRequestAndLoadFiles(Messages.Message testRequest)
    {
      string localDir_ = "";
      RequestInfo rqi = new RequestInfo();
      rqi.requestInfo = extractTests(testRequest);
      List<string> files = extractCode(rqi.requestInfo);

      localDir_ = makeKey(testRequest.author);            // name of temporary dir to hold test files
      rqi.tempDirName = localDir_;
      lock (sync_)
      {
        filePath_ = System.IO.Path.GetFullPath(localDir_);  // LoadAndTest will use this path
        TLS[Thread.CurrentThread.ManagedThreadId] = filePath_;
      }
      Console.Write("\n  creating local test directory \"" + localDir_ + "\"");
      System.IO.Directory.CreateDirectory(localDir_);

      Console.Write("\n  loading code from Repository");
     Sender snd = new Sender();
     snd.channel = Sender.CreateServiceChannel("http://localhost:8000/StreamService");

            foreach (string file in files)
      {
        string name = System.IO.Path.GetFileName(file);
        string dst = System.IO.Path.Combine(localDir_, name);
          try
          {
                   int i = snd.download(file, localDir_);
                    if(i == 1)
                    {
                        SendFileTransferFailedMessage(testRequest, name);
                    }
          }
          catch
          {  }
   }
                  ((IChannel)snd.channel).Close();

            Console.WriteLine();
      return rqi;
    }


      

    //----< save results and logs in Repository >--------------------

        bool saveResultsAndLogs(ITestResults testResults, Messages.Message Omsg)
    {
      string logName = testResults.testKey + ".txt";
      string log = "";
      try
      {
                RequestInfo rqi = new RequestInfo();
                rqi.requestInfo = extractTests(Omsg);
                List<string> files = extractCode(rqi.requestInfo);

                log = logName;

        foreach (ITestResult test in testResults.testResults)
        {
                    foreach (ITestInfo info in rqi.requestInfo)
                    {
                        if (info.testName == test.testName)
                        {
                            log += " \n " + "----";
                            log += " \n " + test.testName;
                            log += " \n " + test.testResult;
                            log += " \n " + test.testLog;
                        }
                    }
        }
       log += " \n " + "----";
       Console.Write("\n************Requirement 7, 8 :Sending Log to Repository *******************");
              Messages.Message msg =  makeMessage(Omsg.author, endPoint, repoEndpt);
                msg.body = log;
                msg.userDefined = logName;
                msg.type = "SaveLogs";
               SendMessage(repoEndpt, msg);
      }
      catch
      {
        return false;
      }
      return true;
    }
    //----< run tests >----------------------------------------------
    /*
     * In Project #4 this function becomes the thread proc for
     * each child AppDomain thread.
     */
    ITestResults runTests(Messages.Message testRequest)
    {
      AppDomain ad = null;
      ILoadAndTest ldandtst = null;
      RequestInfo rqi = null;
      ITestResults tr = null;

      try
      {
        //lock (sync_)
        {
          rqi = processRequestAndLoadFiles(testRequest);
          ad = createChildAppDomain();
          ldandtst = installLoader(ad);
        }
        if (ldandtst != null)
        {
          tr = ldandtst.test(rqi, testRequest);
        }
        // unloading ChildDomain, and so unloading the library

        lock (sync_)
        {
          Console.Write("\n  TID" + Thread.CurrentThread.ManagedThreadId + ": unloading: \"" + ad.FriendlyName + "\"\n");
          AppDomain.Unload(ad);
          try
          {
            System.IO.Directory.Delete(rqi.tempDirName, true);
            Console.Write("\n  TID" + Thread.CurrentThread.ManagedThreadId + ": removed directory " + rqi.tempDirName);
          }
          catch (Exception ex)
          {
            Console.Write("\n  TID" + Thread.CurrentThread.ManagedThreadId + ": could not remove directory " + rqi.tempDirName);
            Console.Write("\n  TID" + Thread.CurrentThread.ManagedThreadId + ": " + ex.Message);
          }
        }
        return tr;
      }
      catch(Exception ex)
      {
        Console.Write("\n\n---- {0}\n\n", ex.Message);
        return tr;
      }
    }

        void SendFileTransferFailedMessage(Messages.Message msg, string file)
        {
            Console.Write("\n\nRequirement 3: File not found\n\n");
            Messages.Message nmsg = new Messages.Message();
            nmsg.author = "Test Harness";
            nmsg.to = msg.from;
            nmsg.from = msg.to;
            nmsg.type = "Error Message: File not Found";
            nmsg.body = "Error Message: File not Found \"" + file + "\"";
           comm.sndr.PostMessage(nmsg);
        }

        //----< make TestResults Message >-------------------------------

        Messages.Message makeTestResultsMessage(ITestResults tr, string toendpoint ,string fromEndpoint)
    {
      Messages.Message trMsg = new Messages.Message();
      trMsg.author = "TestHarness";
      trMsg.to = toendpoint;
      trMsg.from = fromEndpoint;
      trMsg.type = "Test Results";
      XDocument doc = new XDocument();
      XElement root = new XElement("testResultsMsg");
      doc.Add(root);
      XElement testKey = new XElement("testKey");
      testKey.Value = tr.testKey;
      root.Add(testKey);
      XElement timeStamp = new XElement("timeStamp");
      timeStamp.Value = tr.dateTime.ToString();
      root.Add(timeStamp);
      XElement testResults = new XElement("testResults");
      root.Add(testResults);
      foreach(ITestResult test in tr.testResults)
      {
        XElement testResult = new XElement("testResult");
        testResults.Add(testResult);
        XElement testName = new XElement("testName");
        testName.Value = test.testName;
        testResult.Add(testName);
        XElement result = new XElement("result");
        result.Value = test.testResult;
        testResult.Add(result);
        XElement log = new XElement("log");
        log.Value = test.testLog;
        testResult.Add(log);
      }
      trMsg.body = doc.ToString();
      return trMsg;
    }
    //----< wait for all threads to finish >-------------------------

    public void wait()
    {
      foreach (Thread t in threads_)
        t.Join();
    }


        //----< not used for Project #2 >--------------------------------

        public Message sendMessage(Message msg)
        {
            return msg;
        }
        //----< main activity of TestHarness >---------------------------

    public void processMessages()
    {
      AppDomain main = AppDomain.CurrentDomain;
      Console.Write("\n  Starting in AppDomain " + main.FriendlyName + "\n");

      ThreadStart doTests = () => {
        while (true)
        {
              Messages.Message msg = comm.rcvr.GetMessage();
              msg.time = DateTime.Now;
              Console.Write("\n  {0} received message:", comm.name);
              if (msg.body == "quit")
                  return;
              if (msg.type == "Test Request")
              {
                  HRTimer.HiResTimer hrt = new HRTimer.HiResTimer();
                  hrt.Start();
                  Console.Write("\n************Requirement 2:Test Request Message Received *************\n" + msg.body);
                  ITestResults testResults = runTests(msg);
                  lock (sync_)
                  {
                      Console.Write("\n************Requirement 7:Test results sent to client *************\n" + msg.body);
                      SendMessage(msg.from, makeTestResultsMessage(testResults,msg.from,endPoint));
                      saveResultsAndLogs(testResults,msg);
                  }
                  hrt.Stop();
                  Console.Write("\nRequirement 12: Test Request Processed in {0} microsec.", hrt.ElapsedMicroseconds);
              }
          }
      };

      int numThreads = 8;

      for(int i = 0; i < numThreads; ++i)
      {
        Console.Write("\n  Creating AppDomain thread");
        Thread t = new Thread(doTests);
        threads_.Add(t);
        t.Start();
      }
    }
    //----< was used for debugging >---------------------------------

    void showAssemblies(AppDomain ad)
    {
      Assembly[] arrayOfAssems = ad.GetAssemblies();
      foreach (Assembly assem in arrayOfAssems)
        Console.Write("\n  " + assem.ToString());
    }
    //----< create child AppDomain >---------------------------------

    public AppDomain createChildAppDomain()
    {
      try
      {
        Console.Write("\n Requirement 4: creating child AppDomain by TID" + Thread.CurrentThread.ManagedThreadId);

        AppDomainSetup domaininfo = new AppDomainSetup();
        domaininfo.ApplicationBase
          = "file:///" + System.Environment.CurrentDirectory;  // defines search path for LoadAndTest library

        //Create evidence for the new AppDomain from evidence of current

        Evidence adevidence = AppDomain.CurrentDomain.Evidence;

        // Create Child AppDomain

        AppDomain ad
          = AppDomain.CreateDomain("ChildDomain", adevidence, domaininfo);

        Console.Write("\n  created AppDomain \"" + ad.FriendlyName + "\"");
        return ad;
      }
      catch (Exception except)
      {
        Console.Write("\n  " + except.Message + "\n\n");
      }
      return null;
    }
    //----< Load and Test is responsible for testing >---------------

    ILoadAndTest installLoader(AppDomain ad)
    {
      ad.Load("LoadAndTest");
      //showAssemblies(ad);
      //Console.WriteLine();

      // create proxy for LoadAndTest object in child AppDomain

      ObjectHandle oh
        = ad.CreateInstance("LoadAndTest", "TestHarness.LoadAndTest");
      object ob = oh.Unwrap();    // unwrap creates proxy to ChildDomain
                                  // Console.Write("\n  {0}", ob);

      // set reference to LoadAndTest object in child

      ILoadAndTest landt = (ILoadAndTest)ob;

      // create Callback object in parent domain and pass reference
      // to LoadAndTest object in child

      landt.setCallback(cb_);
      lock (sync_)
      {
        filePath_ = TLS[Thread.CurrentThread.ManagedThreadId];
        landt.loadPath(filePath_);  // send file path to LoadAndTest
      }
      return landt;
    }
    static void Main(string[] args)
    {
            Console.Title = "//////////////////*****TestHarness Starting********/////////////////////";
            string repoEndpt = Comm<TestHarness>.makeEndPoint("http://localhost", 8080);
            TestHarness th = new TestHarness(repoEndpt);
            th.wait();
            th.waitRcv();
            Console.Write("\n  Press key to terminate service:\n");
            Console.ReadKey();
            Console.Write("\n");
    }
    }
}
