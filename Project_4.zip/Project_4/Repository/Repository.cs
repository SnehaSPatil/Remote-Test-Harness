﻿/////////////////////////////////////////////////////////////////////
// Repository.cs - define basic functionality of repository        //
// ver 1.0                                                         //
// Language:    C#, Visual Studio 2015                             //
// Platform:    Dell XPS 8900, Windows 10                          //
// Application: Test Harness, Software Modelling and Analysis      //
//                                                                 //
// Sneha Patil, CSE681 - Software Modeling and Analysis, Fall 2016 //
/////////////////////////////////////////////////////////////////////
/*
 * Module Operations:
 * -------------------
 * Remote Repository stores dll's. It provides the facility to query
 * the logs stored in repository .
 *
 *
 * Build Process:
 * --------------
 * Required Files:  BasicRepository.cs
 * Compiler command: csc BasicRepository.cs
 *
 * Maintenance History:
    - Ver 1.0 Oct 2016 
 * --------------------*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;
using SWTools;
using System.ServiceModel.Channels;
using System.IO;
using WCF_Peer_Comm;
using Messages;
using System.Xml;
using System.Xml.Linq;



namespace Repository
{
/////////////////////////////////////////////////////////
///Repository works as storage for the libraries and logs    
    class Repository
    {
        [Serializable]
        private class TestResult
        {
            public string testName { get; set; }
            public string testResult { get; set; }
            public string testLog { get; set; }
        }
        [Serializable]
        private class TestResults
        {
            public string testKey { get; set; }
            public DateTime dateTime { get; set; }
            public List<TestResult> testResults { get; set; } = new List<TestResult>();
        }

        public Comm<Repository> comm { get; set; } = new Comm<Repository>();

        public string endPoint { get; } = Comm<Repository>.makeEndPoint("http://localhost", 8080);
        public string LogFilePath { get; } = "..\\..\\..\\Repository\\RepositoryStorage\\LogFiles";
        private Thread rcvThread = null;

        //Constructor
        public Repository()
        {
            comm.rcvr.CreateRecvChannel(endPoint);
            rcvThread = comm.rcvr.start(rcvThreadProc);
        }

        //wait function to be called on receiver thread
        public void wait()
        {
            rcvThread.Join();
        }

        //Helpeer function that makes messages 
        private  Messages.Message makeMessage(string author, string fromEndPoint, string toEndPoint)
        {
            Messages.Message msg = new Messages.Message();
            msg.author = author;
            msg.from = fromEndPoint;
            msg.to = toEndPoint;
            return msg;
        }

        //Thread proc for the receiver thread
        void rcvThreadProc()
        {
            while (true)
            {
                Messages.Message msg = comm.rcvr.GetMessage();
                msg.time = DateTime.Now;
                Console.Write("\n  {0} received message:", comm.name);
                msg.show();
                ParseMessage(msg);
                if (msg.body == "quit")
                    break;
            }
        }

        //Sending message to the givn port address
        public void SendMessage(string endpoint, Messages.Message msg)
        {
            comm.sndr = new WCF_Peer_Comm.Sender();
            Console.WriteLine("\n\nsending message : " + msg);
            comm.sndr.PostMessage(msg);

        }
        
        //Querying the logs
        void queryLogs(Messages.Message msg)
        {
            string queryText = msg.body;
            List<string> queryResults = new List<string>();
            string path = System.IO.Path.GetFullPath(LogFilePath);
            string[] files = System.IO.Directory.GetFiles(LogFilePath, "*.txt");
            foreach (string file in files)
            {
                     string contents = File.ReadAllText(file);
                    if (contents.Contains(queryText))
                    {
                        string name = System.IO.Path.GetFileName(file);
                        queryResults.Add(name);
                    }
   
            }
            if (queryResults == null)
            {
                Messages.Message newMsg = makeMessage("Repository", endPoint, msg.from);
                newMsg.flag = false;
                newMsg.type = "QueryResults";
                newMsg.body = "No results found for your query about " + queryText;
                SendMessage(msg.from, newMsg);
            }
            else
            {
                queryResults.Sort();
                queryResults.Reverse();
                sendLogsList(queryResults, msg);
            }
    }

        //Sending the logs to the client
        public void sendLogs(Messages.Message msg)
        {
            string path = System.IO.Path.GetFullPath(LogFilePath);
            string text = System.IO.File.ReadAllText(System.IO.Path.Combine(path, msg.body));
            Messages.Message newMsg = makeMessage("Repository", endPoint, msg.from);
            newMsg.body = text;
            newMsg.type = "LogResults";
            newMsg.userDefined = msg.body;
            SendMessage(msg.from, newMsg);
        }

      
        //saveing the logs to repository storage
        void saveLogs(Messages.Message msg)
        {
            char[] delimeter = { '\n' };
            string[] lines = msg.body.Split(delimeter);
            System.IO.File.WriteAllLines(System.IO.Path.Combine(LogFilePath, msg.userDefined), lines);
        }

        //Sending the log list to the client
        void sendLogsList(List<string> Qres, Messages.Message msg)
        {
            Messages.Message newMsg = makeMessage("Repository", endPoint, msg.from);
            newMsg.type = "QueryResults";
            foreach (string file in Qres)
            {
                newMsg.body += file + ",";
            }
            SendMessage(msg.from, newMsg);
        }

        //Parsing the message
        public void ParseMessage(Messages.Message msg)
        {
            switch (msg.type)
            {
                case "TestResults":
                    Console.Write("\n************Requirement 9:Test logs sent to client *************\n");
                    sendLogs(msg);
                    break;
                case "QueryLogs":
                    Console.Write("\n************Requirement 9:Query Results sent to client *************\n" );
                    queryLogs(msg);
                    break;
                case "SaveLogs":
                    Console.Write("\n************Requirement 8:Saving logs received from test harness in file********\n" + msg.userDefined);
                    saveLogs(msg);
                    break;
                default:
                   // Console.WriteLine("unknown command");
                    break;
            }
       }

        public static void Main()
        {
            Console.Title = "//////////////////*****Repository Starting********//////////////////";
            WCF_Peer_Comm.Receiver<Repository> rec = new WCF_Peer_Comm.Receiver<Repository>();
            ServiceHost host = WCF_Peer_Comm.Receiver<Repository>.CreateServiceChannel("http://localhost:8000/StreamService");
            host.Open();
            Repository repo = new Repository();
            Console.Write("\n  SelfHosted File Stream Service started");
            Console.Write("\n ========================================\n");
            Console.Write("\n  Press key to terminate service:\n");
            Console.ReadKey();
            Console.Write("\n");
            host.Close();
        }
    }
}
